document.querySelectorAll("[data-confirm]").forEach((element) => {
  element.addEventListener("click", (event) => {
    if (!window.confirm(element.dataset.confirm)) {
      event.preventDefault();
    }
  });
});

(function () {
  const themeKey = "cravingHouseTheme";
  const toggles = Array.from(document.querySelectorAll("[data-theme-toggle]"));

  function getTheme() {
    return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
  }

  function setTheme(nextTheme) {
    const safeTheme = nextTheme === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = safeTheme;
    try {
      localStorage.setItem(themeKey, safeTheme);
    } catch {
      // Preference persistence is optional.
    }

    toggles.forEach((toggle) => {
      const isDark = safeTheme === "dark";
      toggle.classList.toggle("themeToggleDark", isDark);
      toggle.classList.toggle("themeTogglePoster", !isDark);
      toggle.setAttribute("aria-checked", String(isDark));
      toggle.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
      toggle.title = isDark ? "Switch to light mode" : "Switch to dark mode";

      const title = toggle.querySelector(".themeToggleTitle");
      const subtitle = toggle.querySelector(".themeToggleSub");
      if (title) {
        title.textContent = isDark ? "Dark mode" : "Light mode";
      }
      if (subtitle) {
        subtitle.textContent = isDark ? "Midnight glow" : "Golden glow";
      }
    });
  }

  setTheme(getTheme());

  toggles.forEach((toggle) => {
    toggle.addEventListener("click", () => {
      setTheme(getTheme() === "dark" ? "light" : "dark");
    });
  });
})();

(function () {
  const toggle = document.querySelector("[data-nav-toggle]");
  const drawer = document.getElementById("mobile-drawer");
  const overlay = document.querySelector("[data-nav-overlay]");
  const header = document.querySelector(".appHeader");
  const closeTargets = Array.from(document.querySelectorAll("[data-nav-close]"));

  if (!toggle || !drawer || !overlay) {
    return;
  }

  const background = Array.from(document.querySelectorAll(
    ".skipLink, .appHeader, .messages, .appMain, .appFooter"
  ));
  let previousFocus = null;

  function focusableItems() {
    return Array.from(drawer.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex="0"]'
    )).filter((element) => element.getClientRects().length);
  }

  function setOpen(open) {
    const wasOpen = drawer.classList.contains("drawerOpen");
    if (open === wasOpen) return;
    if (open) previousFocus = document.activeElement;
    drawer.inert = !open;
    background.forEach((element) => { element.inert = open; });
    drawer.classList.toggle("drawerOpen", open);
    overlay.classList.toggle("drawerOverlayOpen", open);
    document.body.classList.toggle("navOpen", open);
    toggle.classList.toggle("iconButtonActive", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    drawer.setAttribute("aria-hidden", String(!open));
    overlay.setAttribute("aria-hidden", String(!open));
    if (header) {
      header.dataset.drawerOpen = String(open);
    }
    if (open) {
      drawer.querySelector('button[data-nav-close]').focus();
    } else if (previousFocus && previousFocus.getClientRects().length) {
      previousFocus.focus();
    } else {
      document.getElementById("main-content").focus();
    }
  }

  toggle.addEventListener("click", () => {
    setOpen(!drawer.classList.contains("drawerOpen"));
  });

  overlay.addEventListener("click", () => {
    setOpen(false);
  });

  closeTargets.forEach((target) => {
    target.addEventListener("click", () => {
      setOpen(false);
    });
  });

  window.addEventListener("keydown", (event) => {
    if (!drawer.classList.contains("drawerOpen")) return;
    if (event.key === "Escape") {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === "Tab") {
      const items = focusableItems();
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });
  window.addEventListener("resize", () => {
    if (!toggle.getClientRects().length) setOpen(false);
  });
})();

(function () {
  const scanner = document.querySelector("[data-loyalty-scanner]");

  if (!scanner) {
    return;
  }

  const video = scanner.querySelector("[data-loyalty-scanner-video]");
  const startButton = scanner.querySelector("[data-loyalty-scanner-start]");
  const stopButton = scanner.querySelector("[data-loyalty-scanner-stop]");
  const status = scanner.querySelector("[data-loyalty-scanner-status]");
  const cardCodeInput = document.getElementById("id_card_code");
  const appScriptUrl = document.currentScript && document.currentScript.src;
  const compatibilityDecoderUrl = appScriptUrl
    ? new URL("vendor/jsqr/jsQR.js", appScriptUrl).toString()
    : "/static/django/js/vendor/jsqr/jsQR.js";
  const canvas = document.createElement("canvas");
  const canvasContext = canvas.getContext("2d", { willReadFrequently: true });
  const secureLocalHosts = ["localhost", "127.0.0.1", "::1"];
  let stream = null;
  let detector = null;
  let animationFrame = null;
  let isScanning = false;
  let scannerMode = null;
  let decoderScriptPromise = null;

  function setStatus(message) {
    if (status) {
      status.textContent = message;
    }
  }

  function extractCardCode(value) {
    const match = String(value || "").match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
    return match ? match[0] : String(value || "").trim();
  }

  function cameraNeedsSecureContext() {
    return !window.isSecureContext && !secureLocalHosts.includes(window.location.hostname);
  }

  function cameraUnavailableMessage() {
    if (cameraNeedsSecureContext()) {
      return "Camera scanning needs HTTPS. Open the secure live site or enter the card code manually.";
    }
    return "Camera access is not available in this browser. Enter the card code manually.";
  }

  function cameraErrorMessage(error) {
    if (cameraNeedsSecureContext()) {
      return "Camera scanning needs HTTPS. Open the secure live site or enter the card code manually.";
    }
    if (error && error.name === "NotFoundError") {
      return "No camera was found. Enter the card code manually.";
    }
    if (error && error.name === "NotAllowedError") {
      return "Camera permission was not granted. Enter the card code manually.";
    }
    return "Camera scanner stopped. Enter the card code manually.";
  }

  async function createNativeDetector() {
    if (!("BarcodeDetector" in window)) {
      return null;
    }

    try {
      if (typeof window.BarcodeDetector.getSupportedFormats === "function") {
        const formats = await window.BarcodeDetector.getSupportedFormats();
        if (!formats.includes("qr_code")) {
          return null;
        }
      }
      return new window.BarcodeDetector({ formats: ["qr_code"] });
    } catch (error) {
      return null;
    }
  }

  function loadCompatibilityDecoder() {
    if (window.jsQR) {
      return Promise.resolve(true);
    }
    if (decoderScriptPromise) {
      return decoderScriptPromise;
    }

    decoderScriptPromise = new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = compatibilityDecoderUrl;
      script.async = true;
      script.crossOrigin = "anonymous";
      script.onload = () => resolve(Boolean(window.jsQR));
      script.onerror = () => resolve(false);
      document.head.appendChild(script);
    });

    return decoderScriptPromise;
  }

  async function prepareDecoder() {
    detector = await createNativeDetector();
    if (detector) {
      scannerMode = "native";
      return true;
    }

    if (canvasContext && (await loadCompatibilityDecoder())) {
      scannerMode = "compatibility";
      return true;
    }

    scannerMode = null;
    return false;
  }

  async function detectQrCodes() {
    if (!video || video.readyState < 2) {
      return [];
    }

    if (scannerMode === "native" && detector) {
      return detector.detect(video);
    }

    if (scannerMode === "compatibility" && window.jsQR && canvasContext) {
      const width = video.videoWidth;
      const height = video.videoHeight;

      if (!width || !height) {
        return [];
      }

      canvas.width = width;
      canvas.height = height;
      canvasContext.drawImage(video, 0, 0, width, height);
      const imageData = canvasContext.getImageData(0, 0, width, height);
      const code = window.jsQR(imageData.data, width, height, {
        inversionAttempts: "attemptBoth",
      });

      return code ? [{ rawValue: code.data }] : [];
    }

    return [];
  }

  function stopScanner(message) {
    isScanning = false;
    if (animationFrame) {
      window.cancelAnimationFrame(animationFrame);
      animationFrame = null;
    }
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      stream = null;
    }
    if (video) {
      video.srcObject = null;
    }
    scanner.classList.remove("isScanning");
    if (startButton) {
      startButton.disabled = false;
    }
    if (stopButton) {
      stopButton.disabled = true;
    }
    if (message) {
      setStatus(message);
    }
  }

  async function scanFrame() {
    if (!isScanning || !video) {
      return;
    }

    try {
      const codes = await detectQrCodes();
      if (codes.length && cardCodeInput) {
        cardCodeInput.value = extractCardCode(codes[0].rawValue);
        cardCodeInput.dispatchEvent(new Event("input", { bubbles: true }));
        stopScanner("Card scanned. Check the stamp count, then add stamps.");
        return;
      }
    } catch (error) {
      stopScanner("Camera scanner stopped. Enter the card code manually.");
      return;
    }

    animationFrame = window.requestAnimationFrame(scanFrame);
  }

  async function startScanner() {
    if (isScanning) {
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus(cameraUnavailableMessage());
      return;
    }

    if (startButton) {
      startButton.disabled = true;
    }
    if (stopButton) {
      stopButton.disabled = true;
    }
    setStatus("Preparing camera scanner...");

    if (!(await prepareDecoder())) {
      if (startButton) {
        startButton.disabled = false;
      }
      setStatus("QR decoder could not load. Enter the card code manually.");
      return;
    }

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      video.srcObject = stream;
      await video.play();
      isScanning = true;
      scanner.classList.add("isScanning");
      startButton.disabled = true;
      stopButton.disabled = false;
      setStatus(scannerMode === "native" ? "Scanning..." : "Scanning in compatibility mode...");
      scanFrame();
    } catch (error) {
      stopScanner(cameraErrorMessage(error));
    }
  }

  if (startButton && stopButton && video) {
    startButton.addEventListener("click", startScanner);
    stopButton.addEventListener("click", () => stopScanner("Camera scanner stopped."));
  }
})();

(function () {
  const forms = Array.from(document.querySelectorAll("[data-cart-form]"));
  const resetTimers = new WeakMap();

  if (!forms.length) {
    return;
  }

  function cartStatusText(count) {
    if (!count) {
      return "Empty";
    }
    return `${count} item${count === 1 ? "" : "s"}`;
  }

  function updateCartCount(count) {
    document.querySelectorAll("[data-cart-count]").forEach((badge) => {
      badge.textContent = String(count);
      badge.hidden = count < 1;
      badge.setAttribute("aria-label", `${count} item${count === 1 ? "" : "s"} in cart`);
    });

    document.querySelectorAll("[data-cart-status]").forEach((status) => {
      status.textContent = cartStatusText(count);
    });
  }

  function setButtonLabel(button, label) {
    const labelNode = button.querySelector("[data-add-label]");
    if (labelNode) {
      labelNode.textContent = label;
    } else {
      button.textContent = label;
    }
  }

  forms.forEach((form) => {
    form.addEventListener("submit", async (event) => {
      const button = form.querySelector("[data-add-button]");
      const status = form.querySelector("[data-cart-status-text]");
      if (!button || button.disabled) {
        return;
      }

      event.preventDefault();

      const defaultLabel = button.dataset.defaultLabel || "Add to cart";
      const existingTimer = resetTimers.get(button);
      if (existingTimer) {
        window.clearTimeout(existingTimer);
      }

      button.disabled = true;
      button.classList.remove("isAdded");
      form.classList.add("isSubmitting");
      setButtonLabel(button, "Adding...");
      if (status) {
        status.textContent = "";
      }

      try {
        const response = await window.fetch(form.action, {
          method: "POST",
          body: new FormData(form),
          headers: {
            Accept: "application/json",
            "X-Requested-With": "XMLHttpRequest",
          },
        });

        if (!response.ok) {
          throw new Error("Cart request failed");
        }

        const data = await response.json();
        updateCartCount(Number(data.cart_count || 0));
        button.classList.add("isAdded");
        setButtonLabel(button, "Added");
        if (status) {
          const addOns = Array.isArray(data.add_on_names) && data.add_on_names.length
            ? ` with ${data.add_on_names.join(", ")}`
            : "";
          status.textContent = `${data.item_name || form.dataset.itemName || "Item"}${addOns} added`;
        }

        const resetTimer = window.setTimeout(() => {
          button.classList.remove("isAdded");
          setButtonLabel(button, defaultLabel);
          if (status) {
            status.textContent = "";
          }
          resetTimers.delete(button);
        }, 1100);
        resetTimers.set(button, resetTimer);
      } catch (error) {
        form.submit();
        return;
      } finally {
        form.classList.remove("isSubmitting");
        button.disabled = false;
      }
    });
  });
})();
